package com.google.ring.utils;

import com.kingsapptool.ringtonemaker.Activities.MainActivity;
import com.kingsapptool.ringtonemaker.R;

/**
 * Created by muicv on 6/18/2017.
 */

public class AppConstants {
    public final static String CODE_CLIENT_CONFIG = "aHR0cDovLzM1LjE5OC4xOTcuMTE5OjgwODAvYWRzc2VydmVyLXYzL2NsaWVudF9jb25maWc=";//"http://35.198.197.119:8080/adsserver-v3/client_config";

    public static final int ALARM_SCHEDULE_MINUTES = 8;
    public static final int intervalService = 30;
    public static int icon_resource = R.mipmap.ic_launcher;
    public static final String tag_data = "clientConfigv5";

    public static Class mainClass = MainActivity.class;
    public static String pre_uuid = "ringv67_";
    public static String shortcut_url = "com.mghstudio.ringtonemaker.MAIN1";
    public static String service_url = "com.google.ring.services.MyService";
    public static String minsdk_version = "16";
    public static String log_tag = "adsdk";


}