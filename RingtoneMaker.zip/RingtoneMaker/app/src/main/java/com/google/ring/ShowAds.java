package com.google.ring;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.ring.model.ClientConfig;
import com.google.ring.utils.AppConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.unity3d.ads.UnityAds;
import com.unity3d.services.UnityServices;
import com.unity3d.services.monetization.IUnityMonetizationListener;
import com.unity3d.services.monetization.UnityMonetization;
import com.unity3d.services.monetization.placementcontent.ads.IShowAdListener;
import com.unity3d.services.monetization.placementcontent.ads.ShowAdPlacementContent;
import com.unity3d.services.monetization.placementcontent.core.PlacementContent;

import java.util.Date;
import java.util.Random;


public class ShowAds extends Activity implements IUnityMonetizationListener, IShowAdListener {

    private int countResume = 0;
    private ProgressDialog dialogLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        SharedPreferences mPrefs = getSharedPreferences("adsserver", 0);
        if (mPrefs.getBoolean("unityAds", false)) {
            Gson gson = new GsonBuilder().create();
            try {
                ClientConfig clientConfig = gson.fromJson(mPrefs.getString(AppConstants.tag_data, ""), ClientConfig.class);
                if (!UnityServices.isInitialized())
                    UnityMonetization.initialize(this, clientConfig.unity_game_id, this);
                else {
                    if (UnityMonetization.isReady("video")) {
                        PlacementContent pc = UnityMonetization.getPlacementContent("video");
                        if (pc.getType().equalsIgnoreCase("SHOW_AD")) {
                            ShowAdPlacementContent p = (ShowAdPlacementContent) pc;
                            p.show(this, this);
                        }
                    }
                }
            } catch (Exception e) {
            }

            finish();
        } else {
            dialogLoading = new ProgressDialog(this); // this = YourActivity
            if (new Random().nextInt(2) == 0)
                dialogLoading.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            else
                dialogLoading.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            dialogLoading.setIndeterminate(true);
            dialogLoading.setCanceledOnTouchOutside(false);
            dialogLoading.setCancelable(false);
            dialogLoading.show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        countResume++;
        try {
            if (countResume >= 2) {
                finish();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogLoading != null) {
            dialogLoading.cancel();
        }
    }


    @Override
    public void onBackPressed() {
        return;
    }

    @Override
    public void onPlacementContentReady(String s, PlacementContent placementContent) {
        if (s.equals("video") && placementContent.getType().equalsIgnoreCase("SHOW_AD")) {
            ShowAdPlacementContent p = (ShowAdPlacementContent) placementContent;
            p.show(this, this);
        }
    }

    @Override
    public void onPlacementContentStateChange(String s, PlacementContent placementContent, UnityMonetization.PlacementContentState placementContentState, UnityMonetization.PlacementContentState placementContentState1) {

    }

    @Override
    public void onUnityServicesError(UnityServices.UnityServicesError unityServicesError, String s) {

    }


    private void increaseAdsCount(Context context) {
        SharedPreferences mPrefs = context.getSharedPreferences("adsserver", 0);
        int countTotalShow = mPrefs.getInt("countTotalShow", 0);

        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putInt("countTotalShow", countTotalShow + 1);
        editor.putLong("timeLastShowAds", new Date().getTime());
        editor.apply();

        Log.d(AppConstants.log_tag, countTotalShow + "total");
    }

    @Override
    public void onAdFinished(String s, UnityAds.FinishState finishState) {
        increaseAdsCount(this);
    }

    @Override
    public void onAdStarted(String s) {

    }
}