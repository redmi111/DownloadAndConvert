package com.kingsapptool.ringtonemaker.Views;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}