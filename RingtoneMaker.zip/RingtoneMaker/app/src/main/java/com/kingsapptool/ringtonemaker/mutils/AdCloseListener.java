package com.kingsapptool.ringtonemaker.mutils;

public interface AdCloseListener
{
    public void onAdClose();
}
