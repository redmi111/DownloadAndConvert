package com.kingsapptool.ringtonemaker.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.codemybrainsout.ratingdialog.RatingDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.ring.model.ClientConfig;
import com.kobakei.ratethisapp.RateThisApp;
import com.kingsapptool.ringtonemaker.Adapters.CellAdapter;
import com.kingsapptool.ringtonemaker.R;
import com.kingsapptool.ringtonemaker.Ringdroid.Utils;
import com.kingsapptool.ringtonemaker.mutils.InterstitialUtils;

import static com.kingsapptool.ringtonemaker.Ringdroid.Constants.REQUEST_ID_MULTIPLE_PERMISSIONS;
import static com.kingsapptool.ringtonemaker.Ringdroid.Constants.REQUEST_ID_READ_CONTACTS_PERMISSION;

public class MainActivity extends AppCompatActivity {
    private AdView adView;
    SharedPreferences mPrefs;
    static final String PREFERENCES_NAME = "instagramPro";
    SharedPreferences.Editor editor;
    boolean rate = false;
    RatingDialog ratingDialog;
    private static final String[] items = new String[]{
            "Contacts", "Ringtone", "Settings", "More apps"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null)
            getSupportActionBar().hide();
        setContentView(R.layout.activity_main);


        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new CellAdapter(this, items));
        gridView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        if (Utils.checkAndRequestContactsPermissions(MainActivity.this)) {
                            Intent contact = new Intent(MainActivity.this, ContactActivity.class);
                            startActivity(contact);
                        }
                        break;
                    case 1:
                        if (Utils.checkAndRequestPermissions(MainActivity.this, true)) {
                            Intent i = new Intent(MainActivity.this, RingdroidSelectActivity2.class);
                            startActivity(i);
                        }
                        break;
                    case 2:
                        Intent j = new Intent(MainActivity.this, SettingsActivity.class);
                        startActivity(j);
                        break;
                    case 3:
                        Intent a = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=DINH+VIET+HUNG"));
                        startActivity(a);
                }
            }
        });


        mPrefs = getApplicationContext().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        editor = mPrefs.edit();
        rate = mPrefs.getBoolean("rate", false);
        ratingDialog = new RatingDialog.Builder(this)
                .session(1)
                .threshold(4)
                .title("How was your experience with us?")
                .titleTextColor(R.color.black)
                .positiveButtonText("Not Now")
                .positiveButtonTextColor(R.color.black)
                .negativeButtonText("Never")
                .negativeButtonTextColor(R.color.black)
                .formTitle("Submit Feedback")
                .ratingBarBackgroundColor(R.color.grey_400)
                .formHint("Tell us where we can improve")
                .formSubmitText("Submit")
                .formCancelText("Cancel")
                .ratingBarColor(R.color.tuan)
                .feedbackTextColor(R.color.black)
                .onRatingChanged((float rating, boolean thresholdCleared) -> {
                    editor.putBoolean("rate", true);
                    editor.apply();
                })
                .onRatingBarFormSumbit((String feedback) ->
                        Toast.makeText(this, "Thanks for feedback !", Toast.LENGTH_SHORT).show()
                ).build();
        Log.d("tuancon", "" + rate);

        if (!rate)
            ratingDialog.show();


        InterstitialUtils.getSharedInstance().init(getApplicationContext());
        ClientConfig clientConfig = InterstitialUtils.getSharedInstance().clientConfig;
        if (clientConfig != null && clientConfig.isGoogleIp == 0 && clientConfig.max_percent_ads > 0) {
            adView = new AdView(this);
            adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
            adView.setAdUnitId("ca-app-pub-5849952604847046/3290639178");
            RelativeLayout adContainer = findViewById(R.id.AdView);
            adContainer.addView(adView);
            adView.loadAd(new AdRequest.Builder().build());
        }

        RateThisApp.onCreate(this);
        RateThisApp.Config config = new RateThisApp.Config(0, 0);
        config.setMessage(R.string.rate_5_stars);
        RateThisApp.init(config);
    }

    @Override
    protected void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_ID_READ_CONTACTS_PERMISSION: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(MainActivity.this, "Please grant permission to continue!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                Intent contact = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(contact);
                break;
            }

            case REQUEST_ID_MULTIPLE_PERMISSIONS: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Please grant permission to continue!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                Intent select = new Intent(getApplicationContext(), RingdroidSelectActivity2.class);
                startActivity(select);

                break;
            }
        }
    }
}
