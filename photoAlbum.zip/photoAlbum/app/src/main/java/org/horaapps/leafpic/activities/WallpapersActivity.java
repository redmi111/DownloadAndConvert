package org.horaapps.leafpic.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.ArrayMap;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.AdapterView;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.horaapps.leafpic.R;
import org.horaapps.leafpic.adapters.WallpapersAdapter;
import org.horaapps.leafpic.interfaces.EndlessScrollListener;
import org.horaapps.leafpic.util.AnimationUtils;
import org.horaapps.leafpic.util.AppConstants;
import org.horaapps.leafpic.util.Measure;
import org.horaapps.leafpic.util.Model;
import org.horaapps.leafpic.util.WallpapersModel;
import org.horaapps.leafpic.util.preferences.Prefs;
import org.horaapps.leafpic.views.GridSpacingItemDecoration;
import org.horaapps.liz.ThemedActivity;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;

import javax.annotation.ParametersAreNonnullByDefault;

import butterknife.BindView;
import butterknife.ButterKnife;
import jp.wasabeef.recyclerview.animators.LandingAnimator;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WallpapersActivity extends ThemedActivity {
    @BindView(R.id.grid_view)
    GridView grid_view;

    private GridSpacingItemDecoration spacingDecoration;
    private WallpapersAdapter adapter;
    private Context context;
    private ArrayList<Model> wpList;
    private String urlRequest ;
    private boolean isLoading = true;
    private boolean canLoadMore = true;
    private int page = 0;
    private ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper);
        ButterKnife.bind(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setBackgroundColor(getPrimaryColor());
        setSupportActionBar(toolbar);
        context = getApplicationContext();

        urlRequest = AppConstants.URL_CLIENT_CONFIG + "?id_game=" + getPackageName();
        context = getApplicationContext();
        wpList = new ArrayList<>();
        wpList.clear();
        adapter = new WallpapersAdapter(context,WallpapersActivity.this, wpList);
        grid_view.setAdapter(adapter);
        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Wallpapers");
        }
        SharedPreferences mPrefs;
        mPrefs = getSharedPreferences("adsserver", 0);



        if (!mPrefs.contains("uuid")) {
            String uuid = UUID.randomUUID().toString();
            mPrefs.edit().putString("uuid", "music" + uuid).apply();
        }

        getData(isLoading, String.valueOf(page));

        grid_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String url = wpList.get(position).url_s;
                Intent intent = new Intent(WallpapersActivity.this, WallpaperDetailActivity.class);
                intent.putExtra("url", url);
                startActivity(intent);
            }
        });
    }

    public void showProgress(){
        progressDialog = new ProgressDialog(context,R.style.AlertDialog_Light);
        progressDialog.setMessage("Loading wallpaper ...");
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.show();
    }

    public void dismissProgress(){
        progressDialog.dismiss();
    }


    private void getData(boolean isLoading,String p){


        if (isLoading){
            Map<String, Object> jsonParams = new ArrayMap<>();
            jsonParams.put("user_id", "1");
            jsonParams.put("page_number", p);

            RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"), (new JSONObject(jsonParams)).toString());

            OkHttpClient client = new OkHttpClient();
            Request okRequest = new Request.Builder()
                    .url(urlRequest)
                    .post(body)
                    .build();

            client.newCall(okRequest).enqueue(new Callback() {
                @Override
                @ParametersAreNonnullByDefault
                public void onFailure(okhttp3.Call call, IOException e) {
                    canLoadMore = false;
                    e.printStackTrace();
                }

                @Override
                @ParametersAreNonnullByDefault
                public void onResponse(okhttp3.Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Gson gson = new GsonBuilder().create();
                        WallpapersModel result = gson.fromJson(response.body().string(), WallpapersModel.class);
                        ArrayList<Model> temp;
                        temp = result.getWallpapers();

                        if (temp != null){
                            wpList.clear();
                            wpList.addAll(temp);


                            WallpapersActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    adapter.notifyDataSetChanged();
                                }
                            });
                        }else
                            canLoadMore = false;

                    } else {
                        Log.d("tuanvn", "" + response.code());
                    }
                }
            });

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_wallpaper, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (page <= 0){
            menu.findItem(R.id.previous_page).setEnabled(false);
        }else
            menu.findItem(R.id.previous_page).setEnabled(true);

        if (page >= 50){
            menu.findItem(R.id.next_page).setEnabled(false);
        }else
            menu.findItem(R.id.next_page).setEnabled(true);

        menu.findItem(R.id.pages).setTitle("page " + String.valueOf(page + 1));
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.previous_page:
                page--;
                getData(true,String.valueOf(page));
                invalidateOptionsMenu();
                return true;
            case R.id.next_page:
                page++;
                getData(true,String.valueOf(page));
                invalidateOptionsMenu();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
