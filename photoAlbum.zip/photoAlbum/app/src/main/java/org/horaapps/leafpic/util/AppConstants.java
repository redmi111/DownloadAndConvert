package org.horaapps.leafpic.util;

public class AppConstants {
    public final static String URL_CLIENT_CONFIG = "http://wallpapersdomain.com/million_plus_wallpapers/a_get_popular.php";
}
