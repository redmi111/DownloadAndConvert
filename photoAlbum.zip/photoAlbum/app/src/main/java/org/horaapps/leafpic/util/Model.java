package org.horaapps.leafpic.util;

import com.google.gson.annotations.SerializedName;

public class Model {
    @SerializedName("wallpaper_id")
    public int wallpaper_id;
    @SerializedName("url_f")
    public String url_f;
    @SerializedName("url_s")
    public String url_s;
}
