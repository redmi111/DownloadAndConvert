package org.horaapps.leafpic.util;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class WallpapersModel {
    @SerializedName("wallpapers")
    public ArrayList<Model> wallpapers ;

    public ArrayList<Model> getWallpapers() {
        return wallpapers;
    }
    public int result ;
}
