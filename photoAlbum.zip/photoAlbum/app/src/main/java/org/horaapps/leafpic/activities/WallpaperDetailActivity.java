package org.horaapps.leafpic.activities;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
//import com.facebook.ads.Ad;
//import com.facebook.ads.AdError;
//import com.facebook.ads.InterstitialAd;
//import com.facebook.ads.InterstitialAdListener;

import org.horaapps.leafpic.R;
import org.horaapps.leafpic.util.preferences.Prefs;
import org.horaapps.liz.ThemedActivity;

import java.io.File;

public class WallpaperDetailActivity extends ThemedActivity {
    private DownloadManager dm;
    private String url;
//    private InterstitialAd interstitialAd;
    Toolbar toolbar;
    private ProgressDialog progressDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper_detail);
        updateTheme();
        ImageView imageView = findViewById(R.id.image_detail);
//        FloatingActionButton download = findViewById(R.id.fab);

        toolbar = findViewById(R.id.toolbar);
//        toolbar.setBackgroundColor(getPrimaryColor());
        setSupportActionBar(toolbar);
        progressDialog = new ProgressDialog(this, R.style.AlertDialog_Light);
        progressDialog.setMessage("Loading wallpaper ...");
        progressDialog.setCancelable(false);
        progressDialog.setIndeterminate(true);
        progressDialog.show();


//        Log.d("checkRate", "" + RateThisApp.getLaunchCount(getApplicationContext()));


        dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
//        interstitialAd = new InterstitialAd(this, "359243314827472_359243381494132");
//        interstitialAd.setAdListener(new InterstitialAdListener() {
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        });
//
//        interstitialAd.loadAd();


        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("");
        }

        if (getIntent().getStringExtra("url") != null) {
            url = getIntent().getStringExtra("url");
            RequestOptions options = new RequestOptions()
                    .format(DecodeFormat.PREFER_ARGB_8888)

                    .error(org.horaapps.leafpic.R.drawable.ic_error)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

            Glide.with(imageView.getContext())
                    .load(url)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model,
                                                    Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target,
                                                       DataSource dataSource, boolean isFirstResource) {
                            progressDialog.dismiss();
                            return false;
                        }
                    })
                    .apply(options)
                    .into(imageView);
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_wallpaper_detail, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.download_button:
                Uri uri = Uri.parse(url);
                DownloadData(uri);

//                boolean isRate = Prefs.getRated();
//                if (!isRate && interstitialAd != null && interstitialAd.isAdLoaded()) {
//                    interstitialAd.show();
//                }

                Toast.makeText(getApplicationContext(), "Wallpaper is downloading", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void DownloadData(Uri uri) {

        File direct = new File(Environment.getExternalStorageDirectory()
                + "/photoAlbum");

        if (!direct.exists()) {
            direct.mkdirs();
        }

        // Create request for android download manager
        dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(uri);

        request.allowScanningByMediaScanner();
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        //Setting title of request
        request.setTitle("Download wallpapers");

        //Setting description of request
        request.setDescription("Wallpaper is downloading.");
        request.setAllowedNetworkTypes(
                DownloadManager.Request.NETWORK_WIFI
                        | DownloadManager.Request.NETWORK_MOBILE)
                .setAllowedOverRoaming(false).setTitle("Download wallpapers")
                .setDescription("Something useful. No, really.")
                .setDestinationInExternalPublicDir("/smartGallery", "wallpaper.jpg");
        dm.enqueue(request);
    }
}
