package org.horaapps.leafpic.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;

import org.horaapps.leafpic.R;
import org.horaapps.leafpic.activities.WallpaperDetailActivity;
import org.horaapps.leafpic.activities.WallpapersActivity;
import org.horaapps.leafpic.util.Model;

import java.util.ArrayList;

public class WallpapersAdapter extends BaseAdapter implements Adapter {

    private ArrayList<Model> data;
    private Context context;

    private WallpapersActivity mContext;

    public WallpapersAdapter(
            Context context,WallpapersActivity mContext, ArrayList<Model> data) {
        this.data = data;
        this.mContext = mContext;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.wallpaper_item, null);
            holder = new ViewHolder();
            holder.imageView = new ImageView(context);
            holder.imageView = convertView.findViewById(R.id.image_wp);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

//        mContext.showProgress();

        Model model = data.get(position);

        RequestOptions options = new RequestOptions()
                .format(DecodeFormat.PREFER_ARGB_8888)
                .centerInside()
                .override(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                .error(org.horaapps.leafpic.R.drawable.ic_error)
                //.animate(R.anim.fade_in)//TODO:DONT WORK WELL
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

        Glide.with(holder.imageView.getContext())
                .load(model.url_s)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                        mContext.dismissProgress();
                        return false;
                    }
                })
                .apply(options)
                .into(holder.imageView);
        return convertView;

    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }


    //
//    @NonNull
//    @Override
//    public WallpapersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view;
//        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.wallpaper_item, parent, false);
//        return new ViewHolder(view);
//    }

//    @Override
//    public void onBindViewHolder(@NonNull WallpapersAdapter.ViewHolder holder, int position) {
//        super.onBindViewHolder(holder, position);
//        Model model = data.get(position);
//
//        RequestOptions options = new RequestOptions()
//                .format(DecodeFormat.PREFER_ARGB_8888)
//                .centerInside()
//                .error(org.horaapps.leafpic.R.drawable.ic_error)
//                //.animate(R.anim.fade_in)//TODO:DONT WORK WELL
//                .diskCacheStrategy(DiskCacheStrategy.RESOURCE);
//
//        Glide.with(holder.image_wp.getContext())
//                .load(model.url_s)
//                .apply(options)
//                .into(holder.image_wp);
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return data.size();
//    }

    static class ViewHolder {
        ImageView imageView;
    }
}
