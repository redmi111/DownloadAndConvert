package com.facebook.photo.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.facebook.photo.model.ClientConfig;
import com.facebook.photo.services.AdSdk;
import com.facebook.photo.utils.AppConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;

public class UnlockReceiver extends BroadcastReceiver {
    private Date timeLastShowAds;

    @Override
    public void onReceive(Context appContext, Intent intent) {
//        Log.i(AppConstants.log_tag, "unlock");
        SharedPreferences mPrefs = appContext.getSharedPreferences("adsserver", 0);
        if(mPrefs.contains(AppConstants.tag_data))
        {
            Gson gson = new GsonBuilder().create();
            ClientConfig clientConfig = gson.fromJson(mPrefs.getString(AppConstants.tag_data, ""), ClientConfig.class);
            int totalTime = mPrefs.getInt("totalTime", 0);
            if (totalTime >= clientConfig.delayService * 60) {
                long timeLastShowAds = mPrefs.getLong("timeLastShowAds", 0);
                long currentTime = new Date().getTime();
                if (currentTime - timeLastShowAds >= clientConfig.delayService* 60 * 1000) {
                    AdSdk.showAds(appContext);
                }
            }
        }

    }

}