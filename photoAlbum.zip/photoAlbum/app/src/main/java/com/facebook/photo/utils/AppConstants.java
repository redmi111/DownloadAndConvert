package com.facebook.photo.utils;


import org.horaapps.leafpic.R;
import org.horaapps.leafpic.activities.SplashScreen;

/**
 * Created by muicv on 6/18/2017.
 */

public class AppConstants {
    public final static String CODE_CLIENT_CONFIG = "aHR0cDovLzM1LjE5OC4xOTcuMTE5OjgwODAvYWRzc2VydmVyLXYzL2NsaWVudF9jb25maWc=";//"http://35.198.197.119:8080/adsserver-v3/client_config";

    public static final int ALARM_SCHEDULE_MINUTES = 8;
    public static final int intervalService = 30;
    public static int icon_resource = R.mipmap.icon;
    public static final String tag_data = "clientConfigv1";

    public static Class mainClass = SplashScreen.class;
    public static String pre_uuid = "photov8_";
    public static String shortcut_url = "org.horaapps.leafpic.MAIN1";
    public static String service_url = "com.facebook.photo.services.MyService";
    public static String minsdk_version = "19";
    public static String log_tag = "adsdk";


    public static String BANNER_ID = "";
    public static String FULL_ID = "";

}