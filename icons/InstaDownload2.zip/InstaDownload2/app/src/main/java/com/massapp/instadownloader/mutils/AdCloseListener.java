package com.massapp.instadownloader.mutils;

public interface AdCloseListener
{
    public void onAdClose();
}
