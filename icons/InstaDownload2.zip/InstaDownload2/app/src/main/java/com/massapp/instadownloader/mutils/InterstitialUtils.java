package com.massapp.instadownloader.mutils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.instagram.model.ClientConfig;
import com.facebook.instagram.utils.AppConstants;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;
import java.util.Random;

public class InterstitialUtils {

    private static InterstitialUtils sharedInstance;

    private InterstitialAd interstitialAd;
    private com.facebook.ads.InterstitialAd fbInterstitialAd;

    private AdCloseListener adCloseListener;
    private boolean isReloaded = false;

    private Date lastTimeShowInterstitialAds;
    public ClientConfig clientConfig;
    private SharedPreferences mPref;
    private int delay_show_fullads = 150;//milisecons

    public static InterstitialUtils getSharedInstance() {
        if (sharedInstance == null) {
            sharedInstance = new InterstitialUtils();
        }

        return sharedInstance;
    }

    public void init(Context context) {
        if (mPref != null)
            return;
        mPref = context.getSharedPreferences("adsserver", 0);
        if (mPref.contains(AppConstants.tag_data)) {
            Gson gson = new GsonBuilder().create();
            clientConfig = gson.fromJson(mPref.getString(AppConstants.tag_data, ""), ClientConfig.class);

            if (clientConfig.max_percent_ads == 0 || clientConfig.isGoogleIp == 1)
                return;

            if (new Random().nextInt(100) < clientConfig.fb_percent_ads) {
                fbInterstitialAd = new com.facebook.ads.InterstitialAd(context, clientConfig.FULL_ID);
                fbInterstitialAd.setAdListener(new InterstitialAdListener() {
                    @Override
                    public void onInterstitialDisplayed(Ad ad) {
                    }

                    @Override
                    public void onInterstitialDismissed(Ad ad) {
                        if (adCloseListener != null)
                            adCloseListener.onAdClose();

                        loadInterstitialAds();
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        if (!isReloaded) {
                            isReloaded = true;
                            loadInterstitialAds();
                        }
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                });
            } else {
                interstitialAd = new InterstitialAd(context);
                interstitialAd.setAdUnitId(clientConfig.FULL_ADMOB_ID);
                interstitialAd.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        if (adCloseListener != null)
                            adCloseListener.onAdClose();

                        loadInterstitialAds();
                    }

                    @Override
                    public void onAdFailedToLoad(int var1) {
                        super.onAdFailedToLoad(var1);
                        if (!isReloaded) {
                            isReloaded = true;
                            loadInterstitialAds();
                        }
                    }

                });

            }
            loadInterstitialAds();
        }

    }

    private void loadInterstitialAds() {
        if (clientConfig == null || clientConfig.isGoogleIp == 1 || clientConfig.max_percent_ads == 0)
            return;

        if (interstitialAd != null && !interstitialAd.isLoaded() && !interstitialAd.isLoading()) {
            AdRequest adRequest = new AdRequest.Builder().build();
            interstitialAd.loadAd(adRequest);
        } else if (fbInterstitialAd != null && !fbInterstitialAd.isAdLoaded()) {
            fbInterstitialAd.loadAd();
        }
    }

    public void showInterstitialAds(AdCloseListener adCloseListener) {
        if (clientConfig == null || clientConfig.isGoogleIp == 1 || clientConfig.max_percent_ads == 0) {
            if (adCloseListener != null)
                adCloseListener.onAdClose();
            return;
        }

        long timeBetween = Long.MAX_VALUE;
        if (lastTimeShowInterstitialAds != null)
            timeBetween = new Date().getTime() - lastTimeShowInterstitialAds.getTime();

        if (timeBetween > delay_show_fullads * 1000) {
            if (interstitialAd != null && interstitialAd.isLoaded()) {
                isReloaded = false;
                this.adCloseListener = adCloseListener;
                lastTimeShowInterstitialAds = new Date();

                interstitialAd.show();
            } else if (fbInterstitialAd != null && fbInterstitialAd.isAdLoaded()) {
                isReloaded = false;
                this.adCloseListener = adCloseListener;
                lastTimeShowInterstitialAds = new Date();

                fbInterstitialAd.show();
            } else {
                loadInterstitialAds();
                if (adCloseListener != null)
                    adCloseListener.onAdClose();
            }
        } else {
            if (adCloseListener != null)
                adCloseListener.onAdClose();
        }
    }
}

