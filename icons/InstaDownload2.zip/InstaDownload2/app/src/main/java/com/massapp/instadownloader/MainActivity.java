package com.massapp.instadownloader;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.codemybrainsout.ratingdialog.RatingDialog;
import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.massapp.instadownloader.mutils.InterstitialUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
        , BaseSliderView.OnSliderClickListener, ViewPagerEx.OnPageChangeListener {

    EditText edtURL;
    TextView edtCaption, page_number;
    Button btnSubmit, btnSave, btnCopy, btnRepost, btnPaste;
    ImageView imgView;
    ImageButton imgPlay;
    ProgressBar progressBar;
    RelativeLayout relative_layout;
    AdView mAdView;
    final String TAG = "tuancon";

    int posisi;
    int photoposition;
    int fixposition;
    private int check_download = 0;
    static final int permission = 1;
    private int previousPosition = 0;
    private static int SLIDER_COUNT = 1;

    HashMap<String, String> url_maps = new HashMap<>();
    SliderLayout mDemoSlider;
    PagerIndicator pagerIndicator;
    DefaultSliderView textSliderView;
    int selectedColor;
    int unSelectedColor;

    ArrayList<String> videolink = new ArrayList<>();
    ArrayList<String> photolink = new ArrayList<>();
    ArrayList<String> videoposition = new ArrayList<>();

    String link, filename, repost;
    Model model = new Model();
    static final String PREFERENCES_NAME = "instagramPro";
    SharedPreferences mPref;
    SharedPreferences.Editor editor;
    boolean rate = false;
    RatingDialog ratingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPref = getApplicationContext().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        editor = mPref.edit();
        rate = mPref.getBoolean("rate", false);

        ratingDialog = new RatingDialog.Builder(this)
                .session(2)
                .threshold(4)
                .title("How was your experience with us?")
                .titleTextColor(R.color.black)
                .positiveButtonText("Not Now")
                .positiveButtonTextColor(R.color.black)
                .negativeButtonText("Never")
                .negativeButtonTextColor(R.color.black)
                .formTitle("Submit Feedback")
                .ratingBarBackgroundColor(R.color.grey_400)
                .formHint("Tell us where we can improve")
                .formSubmitText("Submit")
                .formCancelText("Cancel")
                .ratingBarColor(R.color.accent_amber)
                .feedbackTextColor(R.color.black)
                .onRatingChanged((float rating, boolean thresholdCleared) -> {
//                        Toast.makeText(MainActivity.this, "rating change", Toast.LENGTH_SHORT).show();
                    editor.putBoolean("rate", true);
                    editor.apply();
                })
                .onRatingBarFormSumbit((String feedback) ->
                        Toast.makeText(this, "Thanks for feedback !", Toast.LENGTH_SHORT).show()
                ).build();

        if (!rate)
            ratingDialog.show();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        mAdView = findViewById(R.id.adView);
        pagerIndicator = findViewById(R.id.custom_indicator);
        relative_layout = findViewById(R.id.relative_layout);
        mDemoSlider = findViewById(R.id.slider);
        edtURL = findViewById(R.id.edtUrl);
        edtCaption = findViewById(R.id.edtCaption);
        btnSubmit = findViewById(R.id.btnSubmit);
        imgView = findViewById(R.id.imgView);
        page_number = findViewById(R.id.page_number);
        btnSave = findViewById(R.id.btnSave);
        btnCopy = findViewById(R.id.btnCopy);
        btnRepost = findViewById(R.id.btnRepost);
        btnPaste = findViewById(R.id.btnPaste);
        progressBar = findViewById(R.id.progress);
        imgPlay = findViewById(R.id.imgPlay);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        checkPermission();

        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        selectedColor = Color.parseColor("#3F51B5");
        unSelectedColor = Color.parseColor("#E0E0E0");
        mDemoSlider.setDuration(2000);
        pagerIndicator.setDefaultIndicatorColor(selectedColor, unSelectedColor);
        mDemoSlider.setCustomIndicator(pagerIndicator);
        btnSubmit.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        imgPlay.setOnClickListener(this);
        btnPaste.setOnClickListener(this);
        btnRepost.setOnClickListener(this);
        btnCopy.setOnClickListener(this);


        edtURL.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() == 0) {
                    btnSubmit.setText("HOW TO USE");
                } else {
                    btnSubmit.setText("SUBMIT URL");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        InterstitialUtils.getSharedInstance().init(getApplicationContext());
    }

    @Override
    protected void onStop() {
        // To prevent a memory leak on rotation, make sure to call stopAutoCycle() on the slider before activity or fragment is destroyed
        mDemoSlider.stopAutoCycle();
        super.onStop();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.insta_app:
                String apppackage = "com.instagram.android";
                try {
                    Intent i = getPackageManager().getLaunchIntentForPackage(apppackage);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(this, "You have not installed Instagram", Toast.LENGTH_LONG).show();
                }
                return true;

            case R.id.setting:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;
        }
        return true;
    }

    @Override
    public void onSliderClick(BaseSliderView slider) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

        for (int i = 0; i < videoposition.size(); i++) {

            if (position == Integer.parseInt(videoposition.get(i))) {
                this.posisi = position;
                this.fixposition = i;
            }
        }

        if (position == posisi) {
            imgPlay.setVisibility(View.VISIBLE);

        } else {
            this.photoposition = position;
            imgPlay.setVisibility(View.GONE);
        }

        if ((previousPosition == SLIDER_COUNT) && (SLIDER_COUNT == 0)) {
            page_number.setVisibility(View.GONE);
            return;
        }

        //disable swipe at first or last slide
        //swipe left to right
        if (previousPosition == SLIDER_COUNT && position == 0) {
            if (SLIDER_COUNT != 1) {
                mDemoSlider.movePrevPosition();
                return;
            }
        }
        // swipe right to left
        else if (previousPosition == 0 && position == SLIDER_COUNT) {
            if (position != 1) {
                mDemoSlider.moveNextPosition();
                return;
            }
        }
        previousPosition = position;
        String text = String.format(getResources().getString(R.string.page_number), position + 1, SLIDER_COUNT + 1);
        page_number.setText(text);
        if (!(videolink.size() > 0) || SLIDER_COUNT == 1)
            page_number.setVisibility(View.VISIBLE);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public void getSave() {

        File direct = new File(Environment.getExternalStorageDirectory()
                + "/InstagramDownloaderPro");

        boolean isExists = direct.exists();
        if (!isExists) {
            isExists = direct.mkdirs();
        }

        if (isExists) {


            DownloadManager mgr = (DownloadManager) this.getSystemService(Context.DOWNLOAD_SERVICE);

            Uri downloadUri = null;
            if (imgPlay.getVisibility() == View.VISIBLE) {
                if (fixposition < videolink.size()) {
                    downloadUri = Uri.parse(videolink.get(fixposition));
                    filename = videolink.get(fixposition).substring(videolink.get(fixposition).lastIndexOf("/") + 1);
                }

            } else {
                if (photoposition < photolink.size()) {
                    downloadUri = Uri.parse(photolink.get(photoposition));
                    filename = photolink.get(photoposition).substring(photolink.get(photoposition).lastIndexOf("/") + 1);
                }

            }

            if (filename.indexOf('?') > 0) {
                filename = filename.substring(0, filename.lastIndexOf('?'));

            }
            if (downloadUri != null) {
                DownloadManager.Request request = new DownloadManager.Request(
                        downloadUri);
                request.setAllowedNetworkTypes(
                        DownloadManager.Request.NETWORK_WIFI
                                | DownloadManager.Request.NETWORK_MOBILE)
                        .setAllowedOverRoaming(false).setTitle("Instagram Downloader Pro")
                        .setDescription("Downloading...")
                        .setDestinationInExternalPublicDir("/InstagramDownloaderPro", filename);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                Objects.requireNonNull(mgr).enqueue(request);
            }
        }
    }

    public void getMedia() {

        Uri uri = Uri.parse(videolink.get(fixposition));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setDataAndType(uri, "video/mp4");
        startActivity(intent);

    }

    public void getHelp() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Help")
                .setMessage("1. Select post what you want\n2. Click menu on the right side\n3." +
                        " Select copy link\n4. Return to app\n5. Click Paste\n6. Submit URL")
                .setPositiveButton("OK", null)
                .show();
    }

    public void getRepost() {

        if (imgPlay.getVisibility() == View.VISIBLE) {

            filename = videolink.get(fixposition).substring(videolink.get(fixposition).lastIndexOf("/") + 1);

        } else {

            filename = photolink.get(photoposition).substring(photolink.get(photoposition).lastIndexOf("/") + 1);

        }

        if (filename.indexOf('?') > 0) {
            filename = filename.substring(0, filename.lastIndexOf('?'));

        }

        File direct = new File(Environment.getExternalStorageDirectory()
                + "/InstagramDownloaderPro/" + filename);

        if (direct.exists() || check_download > 0) {
            check_download = 0;
            String type = URLConnection.guessContentTypeFromName(filename);
            String mediaPath = Environment.getExternalStorageDirectory() + "/InstagramDownloaderPro/" + filename;
            Intent share = new Intent(Intent.ACTION_SEND);
            File file = new File(mediaPath);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Uri apkURI = FileProvider.getUriForFile(MainActivity.this,
                        MainActivity.this.getPackageName() + ".provider", file);
                share.setType(type);
                share.putExtra(Intent.EXTRA_STREAM, apkURI);

                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                share.setType(type);
                share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            }
            share.setPackage("com.instagram.android");
            startActivity(Intent.createChooser(share, "Share to"));

        } else {
            check_download++;
            getSave();
            getRepost();
        }
    }

    public boolean checkPermission() {
        if ((ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) &&
                (ContextCompat.checkSelfPermission(this,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {

            return true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE}, permission);
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case permission: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(MainActivity.this, "Please grant permission to continue!", Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        switch (v.getId()) {
            case R.id.btnSubmit:
                if (!btnSubmit.getText().toString().equalsIgnoreCase("How To Use")) {
                    relative_layout.setVisibility(View.VISIBLE);
                    mAdView.setVisibility(View.GONE);
                }
                checkUrl();

                break;
            case R.id.btnSave:
                if (checkPermission()) {
                    getSave();
                    rate = mPref.getBoolean("rate", false);
                    if (rate) {
                        InterstitialUtils.getSharedInstance().showInterstitialAds(null);
                    } else {
                        ratingDialog.show();
                    }

                    Toast.makeText(this, "Success, filename : " + filename, Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.imgPlay:
                getMedia();
                break;
            case R.id.btnPaste:
                page_number.setVisibility(View.GONE);
                relative_layout.setVisibility(View.GONE);
                if (mAdView.getVisibility() != View.VISIBLE)
                    mAdView.setVisibility(View.VISIBLE);
                ClipData clipData1 = Objects.requireNonNull(clipboardManager).getPrimaryClip();
                if (clipData1 != null && clipboardManager.getPrimaryClip() != null && clipData1.getItemCount() > 0) {
                    ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
                    if (item != null)
                        edtURL.setText(item.getText().toString());
                }
                break;
            case R.id.btnRepost:
                if (checkPermission())
                    getRepost();
                break;
            case R.id.btnCopy:
                ClipData clipData = ClipData.newPlainText("", repost + edtCaption.getText());
                Objects.requireNonNull(clipboardManager).setPrimaryClip(clipData);
                Toast.makeText(this, "Caption has been copied", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    public void checkUrl() {
        link = edtURL.getText().toString().trim();

        if (TextUtils.isEmpty(link)) {
            getHelp();
        } else {
            try {

                String json = Jsoup.connect("https://api.instagram.com/oembed/?url=" + link).ignoreContentType(true).execute().body();
                JSONObject reader = new JSONObject(json);
                String title = reader.getString("title");
                String author = reader.getString("author_name");
                model.setTitle('\n' + title);
                model.setAuthor('@' + author);

                new Async().execute();

            } catch (IOException | JSONException e) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Error")
                        .setMessage("Error, be sure url correct")
                        .setCancelable(false)
                        .setPositiveButton("OK", null)
                        .show();
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class Async extends AsyncTask<String, String, Void> {

        @Override
        protected void onPostExecute(Void result) {

            SLIDER_COUNT = url_maps.size() - 1;
            for (String name : url_maps.keySet()) {
                try {
                    String[] data = url_maps.get(name).split("batas");
                    if (data.length > 1) {
                        videoposition.add(name);
                        videolink.add(data[1]);


                        if (videoposition.size() > 0)
                            if (0 == Integer.parseInt(videoposition.get(0))) {
                                posisi = 0;
                                fixposition = 0;
                            }


                        if (0 == posisi) {
                            imgPlay.setVisibility(View.VISIBLE);

                        } else {
                            photoposition = 0;
                            imgPlay.setVisibility(View.GONE);
                        }
                        Log.d(TAG, "total_video" + videolink.size());
                    }

                    textSliderView = new DefaultSliderView(MainActivity.this);
                    textSliderView
                            .image(data[0])
                            .setOnSliderClickListener(MainActivity.this);
                    photolink.add(data[0]);
                    mDemoSlider.addSlider(textSliderView);
                    if (photolink.size() > 0)
                        Log.d(TAG, "total_photo" + photolink.size());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            mDemoSlider.stopAutoCycle();
            mDemoSlider.addOnPageChangeListener(MainActivity.this);
            edtCaption.setText(model.getTitle());
            edtCaption.setVisibility(View.VISIBLE);
            btnSave.setVisibility(View.VISIBLE);
            btnRepost.setVisibility(View.VISIBLE);
            btnCopy.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            btnSubmit.setEnabled(true);

//            showInterstitial();
        }


        @Override
        protected Void doInBackground(String... params) {
            String url2 = "";

            try {

                Connection con = Jsoup.connect(link);
                Document doc = con.get();
                repost = "Repost from " + model.getAuthor() + model.getTitle();

                Elements meta = doc.getElementsByTag("script");
                String data = meta.toString().substring(meta.toString().indexOf("window._sharedData") + 21);
                JSONObject reader = new JSONObject(data);
                JSONObject jsonObject = new JSONObject(reader.getString("entry_data"));
                JSONArray jsonArray = jsonObject.getJSONArray("PostPage");
                JSONObject object = jsonArray.getJSONObject(0);
                JSONObject object1 = object.getJSONObject("graphql");
                JSONObject object2 = object1.getJSONObject("shortcode_media");

                if (object2.isNull("edge_sidecar_to_children")) {
                    if (object2.getBoolean("is_video")) {

                        url2 = object2.getString("video_url");
                    }

                    url_maps.put("0", object2.getString("display_url") + "batas" + url2);

                } else {

                    JSONObject object3 = object2.getJSONObject("edge_sidecar_to_children");
                    JSONArray jsonArray1 = object3.getJSONArray("edges");
                    for (int i = 0; i < jsonArray1.length(); i++) {
                        JSONObject zero = jsonArray1.getJSONObject(i);
                        JSONObject node = zero.getJSONObject("node");
                        Boolean cek = node.getBoolean("is_video");
                        if (cek) {

                            url2 = node.getString("video_url");
                        }
                        String display = node.getString("display_url");
                        url_maps.put(String.valueOf(i), display + "batas" + url2);
                    }

                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            Objects.requireNonNull(inputMethodManager).hideSoftInputFromWindow(btnSubmit.getWindowToken(), 0);
            btnSubmit.setEnabled(false);

            btnSave.setVisibility(View.GONE);
            btnCopy.setVisibility(View.GONE);
            btnRepost.setVisibility(View.GONE);
            edtCaption.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
            imgView.setVisibility(View.GONE);
            imgPlay.setVisibility(View.GONE);

            posisi = -1;
            mDemoSlider.removeAllSliders();

            url_maps.clear();
            videolink.clear();
            photolink.clear();
            videoposition.clear();

            textSliderView = null;
            link = edtURL.getText().toString().trim();
        }

    }

//    private void showFullAds() {
//        if (new Random().nextInt(100) < 50) {
//            showInterstitialFB();
//
////            Toast.makeText(this, "show ads FB", Toast.LENGTH_SHORT).show();
//        } else
//            showInterstitialAdmob();
//    }
//
//    public void createInterstitial() {
//        interstitialAd = new InterstitialAd(this);
//        interstitialAd.setAdUnitId("/21617015150/734252/21780745423");
//
//        interstitialFB = new com.facebook.ads.InterstitialAd(this, "377668006313197_377668209646510");
//        loadInterstitial();
//    }
//
//    public void loadInterstitial() {
//        AdRequest interstitialRequest = new AdRequest.Builder().build();
//        interstitialAd.loadAd(interstitialRequest);
//
//        interstitialFB.loadAd();
//    }
//
//    public void showInterstitialAdmob() {
//        if (interstitialAd != null && interstitialAd.isLoaded()) {
//            interstitialAd.show();
//
//            interstitialAd.setAdListener(new AdListener() {
//                @Override
//                public void onAdLoaded() {
//                    // not call show interstitial ad from here
//                }
//
//                @Override
//                public void onAdClosed() {
//                    loadInterstitial();
//                }
//            });
//        } else {
//            loadInterstitial();
//
//        }
//    }
//
//    public void showInterstitialFB() {
//        if (interstitialFB != null && interstitialFB.isAdLoaded()) {
//            interstitialFB.show();
//
//            interstitialFB.setAdListener(new InterstitialAdListener() {
//                @Override
//                public void onInterstitialDisplayed(Ad ad) {
//
//                }
//
//                @Override
//                public void onInterstitialDismissed(Ad ad) {
//                    interstitialFB.loadAd();
//                }
//
//                @Override
//                public void onError(Ad ad, AdError adError) {
//
//                }
//
//                @Override
//                public void onAdLoaded(Ad ad) {
//
//                }
//
//                @Override
//                public void onAdClicked(Ad ad) {
//
//                }
//
//                @Override
//                public void onLoggingImpression(Ad ad) {
//
//                }
//            });
//        } else {
//            loadInterstitial();
//        }
//    }

}
