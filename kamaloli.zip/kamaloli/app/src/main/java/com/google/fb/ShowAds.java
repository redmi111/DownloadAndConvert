package com.google.fb;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import java.util.Random;


public class ShowAds extends Activity {
    private static ShowAds instance;

//    public static ShowAds getInstance() {
//        return instance;
//    }

    private int countResume = 0;
    private ProgressDialog dialogLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        try {
            dialogLoading = new ProgressDialog(this); // this = YourActivity
            if (new Random().nextInt(2) == 0)
                dialogLoading.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            else
                dialogLoading.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            dialogLoading.setIndeterminate(true);
            dialogLoading.setCanceledOnTouchOutside(false);
            dialogLoading.show();
        } catch (Exception e) {
        }

//        if (instance == null)
//            instance = this;
    }

    @Override
    public void onResume() {
        super.onResume();
        countResume++;
        try {
            if (countResume >= 2) {
                if (Build.VERSION.SDK_INT < 21) {
                    finishAffinity();
                } else {
                    finishAndRemoveTask();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialogLoading != null) {
            dialogLoading.cancel();
        }
    }


    @Override
    public void onBackPressed() {
        return;
    }

}
