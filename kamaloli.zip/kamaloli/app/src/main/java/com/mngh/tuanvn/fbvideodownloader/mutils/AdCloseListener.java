package com.mngh.tuanvn.fbvideodownloader.mutils;

public interface AdCloseListener
{
    public void onAdClose();
}
