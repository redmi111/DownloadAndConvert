package com.mngh.tuanvn.fbvideodownloader;

/**
 * Created by KAMAL OLI on 11/08/2017.
 */

public class FacebookVideoUrlManager {
    private String url="";
    public void setUrl(String url){
        this.url=url;
    }
    public String getUrl(){
        return url;
    }
}
