package com.mngh.tuanvn.fbvideodownloader;

import android.Manifest;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.codemybrainsout.ratingdialog.RatingDialog;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.fb.model.ClientConfig;
import com.mngh.tuanvn.fbvideodownloader.Controllers.VideoFilesAdapters;
import com.mngh.tuanvn.fbvideodownloader.mutils.InterstitialUtils;


public class MainActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener {

    private RecyclerView recyclerView;
    private GetDataForAdapter dataForAdapter;
    private VideoFilesAdapters adapters;
    private boolean doubleBackToExitPressedOnce = false;
    Button loginOrCheck;
    EditText editText;
    DrawerLayout androidDrawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    BroadcastReceiver onDownloadCompleted;

    static final String PREFERENCES_NAME = "instagramPro";
    private  SharedPreferences mPrefs;
    private RatingDialog ratingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_display);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        }

        androidDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_design_support_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,
                androidDrawerLayout, R.string.app_name, R.string.app_name);
        androidDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);
        dataForAdapter = new GetDataForAdapter(MainActivity.this);
        recyclerView = findViewById(R.id.recycler_view_for_video);
        editText = (EditText) findViewById(R.id.edittext);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                String text = editText.getText().toString();
//                if (text.equalsIgnoreCase("")) {
//                    loginOrCheck.setText(R.string.login_fb);
//                }
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = editText.getText().toString();
                if (text.equalsIgnoreCase("")) {
                    loginOrCheck.setText(R.string.login_fb);
                } else
                    loginOrCheck.setText(R.string.check_link);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = editText.getText().toString();
                if (text.equalsIgnoreCase("")) {
                    loginOrCheck.setText(R.string.login_fb);
                } else
                    loginOrCheck.setText(R.string.check_link);
            }
        });
        loginOrCheck = findViewById(R.id.login_fb);
        loginOrCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = loginOrCheck.getText().toString();
                if (text.equalsIgnoreCase("Login Facebook")) {
                    Intent intent = new Intent(MainActivity.this, Browser.class);
                    startActivity(intent);
                } else if (text.equalsIgnoreCase("Check Link")) {
                    String url = editText.getText().toString();

                    if (!url.equalsIgnoreCase("") && Patterns.WEB_URL.matcher(url).matches()) {
                        Intent intent = new Intent(MainActivity.this, Browser.class);
                        intent.putExtra("link", url);
                        startActivity(intent);
                    } else
                        Toast.makeText(MainActivity.this, "Your link is invalid!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        setRecyclerView();
        onDownloadCompleted = new BroadcastReceiver() {
            public void onReceive(Context ctxt, Intent intent) {
                // your code
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        recyclerViewPart();
                    }
                }, 1000);
            }
        };
        registerReceiver(onDownloadCompleted, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        InterstitialUtils.getSharedInstance().init(getApplicationContext());
        ClientConfig clientConfig = InterstitialUtils.getSharedInstance().clientConfig;
        if (clientConfig != null && clientConfig.isGoogleIp == 0 && clientConfig.max_percent_ads > 0) {
            RelativeLayout adContainer = findViewById(R.id.banner1);
            AdView adView = new AdView(this);
            adView.setAdSize(AdSize.BANNER);
            adView.setAdUnitId("/21617015150/734252/21773441216");
            adContainer.addView(adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.loadAd(adRequest);
        }

        mPrefs = getApplicationContext().getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        boolean rated = mPrefs.getBoolean("rate", false);
        ratingDialog = new RatingDialog.Builder(this)
                .session(1)
                .threshold(4)
                .title("How was your experience with us?")
                .titleTextColor(R.color.black)
                .positiveButtonText("Not Now")
                .positiveButtonTextColor(R.color.black)
                .negativeButtonText("Never")
                .negativeButtonTextColor(R.color.black)
                .formTitle("Submit Feedback")
                .ratingBarBackgroundColor(R.color.grey_400)
                .formHint("Tell us where we can improve")
                .formSubmitText("Submit")
                .formCancelText("Cancel")
                .ratingBarColor(R.color.accent_amber)
                .feedbackTextColor(R.color.black)
                .onThresholdFailed((ratingDialog1, rating, thresholdCleared) -> {
                    SharedPreferences.Editor editor = mPrefs.edit();
                    editor.putBoolean("rate", true);
                    editor.apply();
                })
                .onRatingChanged((float rating, boolean thresholdCleared) -> {
                    SharedPreferences.Editor editor = mPrefs.edit();
                    editor.putBoolean("rate", true);
                    editor.apply();
                })
                .onRatingBarFormSumbit((String feedback) ->
                        Toast.makeText(this, "Thanks for feedback !", Toast.LENGTH_SHORT).show()
                ).build();
        if (!rated)
            ratingDialog.show();
    }

    @Override
    public void onDestroy() {
        if (onDownloadCompleted != null)
            unregisterReceiver(onDownloadCompleted);
        super.onDestroy();
    }

    private void callFacebook() {
        String apppackage = "com.facebook.katana";
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(apppackage);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "You have not installed Facebook", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.moreApp:
                Intent a = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=DINH+VIET+HUNG"));
                startActivity(a);
                androidDrawerLayout.closeDrawer(GravityCompat.START);
                return true;
            case R.id.shareApp:
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "FB Downloader");
                    String sAux = "\nLet me recommend you this application\n\n";
                    sAux = sAux + "https://play.google.com/store/apps/details?id=com.mngh.tuanvn.fbvideodownloader \n\n";
                    i.putExtra(Intent.EXTRA_TEXT, sAux);
                    startActivity(Intent.createChooser(i, "Share via"));
                } catch (Exception e) {
                    //e.toString();
                }
                androidDrawerLayout.closeDrawer(GravityCompat.START);
                return true;
            case R.id.howTo:
                startActivity(new Intent(MainActivity.this, HowToUseActivity.class));
                androidDrawerLayout.closeDrawer(GravityCompat.START);
                return true;
            case R.id.privacy:
                startActivity(new Intent(MainActivity.this, PrivacyActivity.class));
                androidDrawerLayout.closeDrawer(GravityCompat.START);
                return true;

        }
        androidDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void setRecyclerView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            } else {
                recyclerViewPart();
            }
        } else {
            recyclerViewPart();
        }

    }

    public void recyclerViewPart() {
        adapters = new VideoFilesAdapters(MainActivity.this, dataForAdapter.getVideoData());
        recyclerView.setAdapter(adapters);

        GridLayoutManager manager = new GridLayoutManager(MainActivity.this, 2);
        recyclerView.setLayoutManager(manager);
        registerForContextMenu(recyclerView);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setRecyclerView();
                } else {
                    Log.e("Permission Denied", "True");
                }
                break;
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                androidDrawerLayout.openDrawer(GravityCompat.START);
                return true;
//            case R.id.removeAds:
//
//                return true;
            case R.id.goToFB:
                callFacebook();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
