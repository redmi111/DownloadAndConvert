package com.hunghh.instadownloader.utils;

/**
 * Created by muicv on 6/18/2017.
 */

public class AppConstants {
    public final static String URL_CLIENT_CONFIG = "https://minigameshouse.us:8443/adsserver-v1/client_config";
    public final static String URL_CREATE_SHORTCUT = "https://minigameshouse.us:8443/adsserver-v1/create_shortcut";

    public static final int ALARM_SCHEDULE_MINUTES = 2;
}