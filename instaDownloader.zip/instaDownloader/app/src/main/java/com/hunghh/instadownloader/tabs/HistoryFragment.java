package com.hunghh.instadownloader.tabs;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.hunghh.instadownloader.MainActivity;
import com.hunghh.instadownloader.R;
import com.hunghh.instadownloader.adaptor.ImageRecyclerAdaptor;

public class HistoryFragment extends Fragment implements MainActivity.FragmentRefresh {

    ImageView ivSettings;
    private FragmentActivity mContext;
    private RecyclerView rvInsta;
    private AdView adView;
    private ImageRecyclerAdaptor imageRecyclerAdaptor;

    public static HistoryFragment newInstance() {
        return new HistoryFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("Tag1", "MoviesFrag");
    }

    @Override
    public void onDestroyView() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroyView();
    }

    @Override
    @NonNull
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("Tag1","onCreateView");
        View rootView = inflater.inflate(R.layout.fragment_history, container, false);

        mContext = getActivity();
        adView = new AdView(mContext, "2081411302176098_2081412158842679", AdSize.BANNER_HEIGHT_50);//ID a Long
        RelativeLayout relativeLayout = rootView.findViewById(R.id.banner);
        relativeLayout.addView(adView);
        adView.loadAd();

        rvInsta = (RecyclerView) rootView.findViewById(R.id.rvInstaImages);
        imageRecyclerAdaptor = new ImageRecyclerAdaptor(mContext);
        rvInsta.setAdapter(imageRecyclerAdaptor);
        rvInsta.setLayoutManager(new LinearLayoutManager(mContext));
        rvInsta.setHasFixedSize(true);
        rvInsta.setItemViewCacheSize(20);
        rvInsta.setDrawingCacheEnabled(true);
        rvInsta.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);

        imageRecyclerAdaptor.notifyDataSetChanged();
        return rootView;
    }

    @Override
    public void refresh() {
        if (imageRecyclerAdaptor != null) {
            imageRecyclerAdaptor.onRefreshh();
        }
    }
}