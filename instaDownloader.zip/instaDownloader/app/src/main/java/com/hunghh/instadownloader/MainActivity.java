package com.hunghh.instadownloader;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.os.ConfigurationCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hunghh.instadownloader.Model.AdsConfig;
import com.hunghh.instadownloader.adaptor.TabsPagerAdapter;
import com.hunghh.instadownloader.service.MyService;
import com.hunghh.instadownloader.tabs.DownloadFragment;
import com.hunghh.instadownloader.tabs.HistoryFragment;
import com.hunghh.instadownloader.utils.AppConstants;

import java.io.IOException;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements
        DownloadFragment.OnPostDownload {
    public ViewPager viewPager;
    Toolbar toolbar;
    TabLayout tabLayout;
    private TabsPagerAdapter mAdapter;
    private InterstitialAd interstitialAd;
    private ProgressDialog dialogLoading;
    private SharedPreferences mPrefs;
    private boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initNavDrawerToggel();

        if (Utilities.getStoragePermission(MainActivity.this)) {
            final Intent intent = getIntent();
            if (intent.getData() != null || intent.getStringExtra("android.intent.extra.TEXT") != null) {
                String link;
                if (intent.getData() != null) {
                    link = intent.getData().toString();
                } else {
                    link = intent.getStringExtra("android.intent.extra.TEXT");
                }
                Log.d("caomui", link);
                DownloadFragment.download_Link = link;
            } else {
                dialogLoading = new ProgressDialog(this); // this = YourActivity
                dialogLoading.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                dialogLoading.setIndeterminate(true);
                dialogLoading.setCanceledOnTouchOutside(false);
                dialogLoading.show();
                interstitialAd = new InterstitialAd(this, "2081411302176098_2081412052176023");
                interstitialAd.loadAd();
                interstitialAd.setAdListener(new InterstitialAdListener() {
                    @Override
                    public void onInterstitialDisplayed(Ad ad) {
                    }

                    @Override
                    public void onInterstitialDismissed(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                        Log.d("caomui", "error " + adError.getErrorMessage());

                        dialogLoading.dismiss();
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        if (dialogLoading != null && dialogLoading.isShowing()) {
                            dialogLoading.dismiss();
                            interstitialAd.show();
                            Log.d("caomui", "Showed");
                        }
                    }

                    @Override
                    public void onAdClicked(Ad ad) {

                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {

                    }
                });
            }


        }

        getAppConfig();
    }

    private void initNavDrawerToggel() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initilization
        viewPager = findViewById(R.id.pager);
        mAdapter = new TabsPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(mAdapter);

        tabLayout = findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Download"));
        tabLayout.addTab(tabLayout.newTab().setText("History"));

        tabLayout.setupWithViewPager(viewPager);


    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0) {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        } else {
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
        }
    }

    private void callInstagram() {
        String apppackage = "com.instagram.android";
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(apppackage);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "You have not installed Instagram", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void refreshList() {
        Fragment fragment = mAdapter.getFragment(1);
        if (fragment != null)
            ((HistoryFragment) fragment).refresh();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.instalogo:

                callInstagram();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public interface FragmentRefresh {
        void refresh();
    }

    private void getAppConfig() {

//        Locale locale = ConfigurationCompat.getLocales(Resources.getSystem().getConfiguration()).get(0);
//        Log.d("caomui",locale.getCountry());
//        Log.d("caomui",locale.getLanguage());
//
//        if (true)
//            return;

        mPrefs = getSharedPreferences("adsserver", 0);
        String uuid;
        if (mPrefs.contains("uuid")) {
            uuid = mPrefs.getString("uuid", UUID.randomUUID().toString());
        } else {
            uuid = UUID.randomUUID().toString();
            mPrefs.edit().putString("uuid", "2insta" + uuid).commit();
        }

        OkHttpClient client = new OkHttpClient();
        Request okRequest = new Request.Builder()
                .url(AppConstants.URL_CLIENT_CONFIG + "?id_game=" + getPackageName())
                .build();

        client.newCall(okRequest).enqueue(new Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {

            }

            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                Gson gson = new GsonBuilder().create();
                AdsConfig adsConfig = gson.fromJson(response.body().string(), AdsConfig.class);
                SharedPreferences.Editor editor = mPrefs.edit();
                editor.putInt("intervalService", adsConfig.intervalService);
//                editor.putString("idFullService", adsConfig.idFullService);
                editor.putInt("delayService", adsConfig.delayService);
                editor.putInt("delay_report", adsConfig.delay_report);
//                editor.putString("idFullFbService", adsConfig.idFullFbService);

                if (!mPrefs.contains("delay_retention")) {
                    if (new Random().nextInt(100) < adsConfig.retention) {
                        editor.putInt("delay_retention", adsConfig.delay_retention).commit();
                    } else {
                        editor.putInt("delay_retention", -1);
                    }
                }

                editor.commit();

                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent myIntent = new Intent(MainActivity.this, MyService.class);
                        startService(myIntent);
                    }
                });
            }
        });
    }
}
