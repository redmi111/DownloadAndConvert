package com.hunghh.instadownloader;

public class CheckAds {
    public int isShow;
    public int isBotClick;
    public int delayClick;
    public int x;
    public int y;
}